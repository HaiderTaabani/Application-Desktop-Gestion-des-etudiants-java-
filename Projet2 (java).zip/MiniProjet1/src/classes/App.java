package classes;



import java.awt.FlowLayout;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import javax.swing.BoxLayout;
import javax.swing.ComboBoxEditor;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;



public class App extends JFrame implements ItemListener,  ActionListener{
	JLabel lebelModule = new JLabel("Module");
	         JLabel labelControl = new JLabel("Note Examen");
	         JLabel labelResulat = new JLabel("Resultat :");
	         JLabel labelControlTp = new JLabel("note Tp");
	         JLabel labelControlTd = new JLabel("Note Td");
			TextField txtControle = new TextField(10);
	         TextField txtControleTp = new TextField(10);
	         TextField txtControleTd = new TextField(10);
	         String [] module  = {"POA","OMC","UPD","EAB","GPI"};
	         JComboBox<String> comboModule = new JComboBox<String>(module);
	  JButton btnAfficher= new JButton("aficher");
	  JButton btnQuitter= new JButton("quitter");
	  JPanel panModule =new JPanel();
	  JPanel panControle =new JPanel();JPanel panAfficher  =new JPanel();
	  JPanel panGlobal =new JPanel();
	  
	  public  App() {
		  
		 
		  panModule.setLayout(new FlowLayout());
		  panModule.add(lebelModule);
		  panModule.add(comboModule);	
		  
		  panControle.setLayout(new FlowLayout());
		  panControle.add(labelControl); 
		  panControle.add(txtControle);panControle.add(labelControlTp); panControle.add(txtControleTp);
		  panControle.add(labelControlTd); panControle.add(txtControleTd);
		   
		  panAfficher.setLayout(new FlowLayout());
		  panAfficher.add(btnQuitter);  panAfficher.add(btnAfficher); panAfficher.add(labelResulat);
		  btnAfficher.addActionListener(this);
		  btnQuitter.addActionListener(this);
		  comboModule.addItemListener(this);
		  panGlobal.setLayout(new BoxLayout(panGlobal, BoxLayout.Y_AXIS));
		  panGlobal.add(panModule); panGlobal.add(panControle); panGlobal.add(panAfficher);
		  getContentPane().add(panGlobal);
		 		
		  
		  pack();
		  setLocationRelativeTo(null);
		  setTitle("Bienvenu ");
		  setVisible(true);
		  setSize(800,350);
		    
	  }
		 
		  float calculMoyenne() {
			  try {
				 Float controle = Float.parseFloat(txtControle.getText());
				 Float controleTp = Float.parseFloat(txtControleTp.getText());
				 Float TD  = Float.parseFloat(txtControleTd.getText());
				 return (controle *2 + (controleTp + TD)/2)/3;
				 
			 
			  } catch(NumberFormatException ex) {
				  
				  System.out.println("Entrez des nombres svp");
				  System.out.println(ex);
				  
				  
			  }
			return 0;
			
			
			  
			  
			 }
		  
		  
		  
		  
	  
	  @Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		JButton btn = (JButton)e.getSource();
		if (btn.equals(btnAfficher)) labelResulat.setText("la moyenne" +comboModule.getSelectedItem().toString() 
				+ String.valueOf(calculMoyenne()));
		else 
			System.exit(0);
	}
	@Override
	public void itemStateChanged(ItemEvent e) {
		// TODO Auto-generated method stub
		txtControle.setText("");
		txtControleTp.setText("");
		labelResulat.setText("");
		
	 
	  
	 }
		
	
	public static void main(String[] args) {
		new App();
	

}
	  }

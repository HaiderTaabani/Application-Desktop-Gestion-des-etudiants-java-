package classes;

import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;





public class Authentification extends JFrame implements ActionListener{
	JLabel nomd= new JLabel("Non d'utilistaeur");
	JTextField txtnomd=new  JTextField(15);
	JLabel motp= new JLabel("Mot de passe");
	JPasswordField txtmotp= new JPasswordField(10);
	JButton seconn = new JButton("se conencter");
	JButton sins = new JButton("S'inscrire");
	
	JPanel p1= new JPanel();JPanel p2= new JPanel();JPanel p3= new JPanel();
	
	JPanel p = new JPanel();
	JFrame frame = new JFrame();
	
	public  Authentification() {
		setTitle("S'authentifier (pour utiliser l'app)");
		setSize(400,250);
		
		p1.setLayout(new FlowLayout());
		p1.add(nomd) ;
		p1.add(txtnomd);
		
		p2.setLayout(new FlowLayout());
		p2.add(motp);
		p2.add(txtmotp);
		sins.addActionListener(this);
		seconn.addActionListener(this);
		p3.setLayout(new FlowLayout());
		p3.add(seconn);
		p3.add(sins);
		
		p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
		p.add(p1);p.add(p2);p.add(p3);
		setContentPane(p);
		setLocationRelativeTo(null);
		setVisible(true);
		 
		
		
	
	}

@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
	if(e.getSource()== sins ) {
	
		
	Sinscrire atn = new Sinscrire();
	}
	
	
	
	String user = txtnomd.getText();
	String pass = txtmotp.getText();
	
	
	if(e.getSource()==seconn ) {
		
		
	try {
		
		File filex =new File("yourData.txt");
		
		
		Scanner sc = new Scanner(filex);
		
		
		sc.useDelimiter("[,\n]");
		while(sc.hasNext()) {
			String user1=sc.next();
			String pass1=sc.next();
			if(user.equals(user1.trim()) && pass.equals(pass1.trim())) {
				JOptionPane.showMessageDialog(null, "Bienvenu");
				App atnn=new App();
				atnn.setVisible(true);
				atnn.setTitle("Bienvenu monsieur " + user1);
				this.dispose();
			}else {
				
			
			}
			
		}
	}
		catch(Exception e1)
		{
		
		}
	}
			
			
	
	
}

public static void main(String[] args) {
	new Authentification();
}
}




package classes;



import java.awt.Event;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileOutputStream;
import java.io.PrintWriter;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class Sinscrire extends JFrame implements ActionListener{
	JLabel Nom = new JLabel("Le Nom d'utilisataeur"),daten = new JLabel("date de naicence"),nombree=new JLabel("nombre enf"),
			dater= new JLabel("date recrutrment"), etatc =new JLabel("Etat civile");
	JTextField txtnom = new JTextField(15);JLabel matricule = new JLabel("Mot de passe") ;
			JPasswordField txtMat = new JPasswordField(15);
			JLabel vmat = new JLabel("Votre Mati�re");
			JButton precedent = new JButton("Pr�cedent");
			JButton suivant = new JButton("Enregistrer");
	JComboBox<String> jour = new JComboBox<String>();
			JComboBox<String> journ = new JComboBox<String>();
			
			
			String [] tabmois = {"jan","fev","mar","avr","mai","jui","juit","sept","oct","nov","dec"};
			JComboBox<String> mois = new JComboBox<String>(tabmois);
			String [] tabmoisn = {"jan","fev","mar","avr","mai","jui","juit","sept","oct","nov","dec"};
			JComboBox<String> moisn = new JComboBox<String>(tabmois);
			
			JComboBox<String> annee = new JComboBox<String>();
			
			JComboBox<String> anneen= new JComboBox<String>();
			String [] tabmat = {"POA","OMC","DAW","EAB","GPI"};
			JComboBox<String> jmat=new JComboBox<String>(tabmat);
		
			
	JPanel p1 = new JPanel() ,p2 = new JPanel(),p3 = new JPanel(),p4 = new JPanel(),p5 = new JPanel(),p6 = new JPanel();

	JPanel p = new JPanel();
	
	
	public  Sinscrire() {
		for (int i=1 ; i<=31;i++) {
			journ.addItem(String.valueOf(i));
		}
		for (int i=1950 ; i<=2050;i++) {
			anneen.addItem(String.valueOf(i));
		}
		for (int i=1 ; i<=31;i++) {
			jour.addItem(String.valueOf(i));
		}
		for (int i=1950 ; i<=2050;i++) {
			annee.addItem(String.valueOf(i));
		}
		setTitle("INSCRIPTION");
		setSize(500,500);
		
		p1.setLayout(new FlowLayout());
		p1.add(Nom) ;
		p1.add(txtnom);
		
		p2.setLayout(new FlowLayout());
		p2.add(daten);
		p2.add(journ);
		p2.add(moisn);
		p2.add(anneen);
		
		p3.setLayout(new FlowLayout());
		p3.add(matricule);
		p3.add(txtMat);
		
		p4.setLayout(new FlowLayout());
		p4.add(vmat);
		p4.add(jmat);
		
		p5.setLayout(new FlowLayout());
		p5.add(dater);
		;p5.add(mois);p5.add(annee);
		
		p6.setLayout(new FlowLayout());
		p6.add(precedent);
		p6.add(suivant);		
		
		p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
		p.add(p1);p.add(p2);p.add(p3);p.add(p4);p.add(p5);p.add(p6);
		setContentPane(p);
		setLocationRelativeTo(null);
		setVisible(true);
		precedent.addActionListener(this);
		suivant.addActionListener(this);
		
		
		
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()== precedent) { 
			
			Authentification Atn = new Authentification();
			
			
			}
		String nomut= txtnom.getText();
		String motpass= txtMat.getText();
		
		
		if(e.getSource()==suivant) {
			
		
		try {
		FileOutputStream file = new FileOutputStream("yourData.txt",true);	
		PrintWriter printer =new PrintWriter(file);
		printer.println(nomut+","+motpass);
		JOptionPane.showMessageDialog(null, "enregistr�");
		printer.close();
			
		}
		
		catch(Exception e1)
		{
			
		}
		}
	}
		
		
	
		
	
	
	public static void main(String[] args) {
		new Sinscrire();	
	}
	

}

